// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface TestinvinsensePluginSetup {}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface TestinvinsensePluginStart {}
