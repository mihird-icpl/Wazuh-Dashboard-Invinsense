export const PLUGIN_ID = 'Invinsense';
export const PLUGIN_NAME = 'Invinsense';
