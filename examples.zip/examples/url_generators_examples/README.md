## Access links examples

This example app shows how to:
 - Register a direct access link generator.
 - Handle migration of legacy generators into a new one.

To run this example, use the command `yarn start --run-examples`. Navigate to the access links explorer app