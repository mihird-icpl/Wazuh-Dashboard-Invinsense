## Access links explorer

This example app shows how to:
 - Generate links to other applications
 - Generate dynamic links, when the target application is not known
 - Handle backward compatibility of urls

To run this example, use the command `yarn start --run-examples`.