## Ui actions explorer

This example ui actions explorer app shows how to:
 - Add custom ui actions to existing triggers
 - Add custom triggers


To run this example, use the command `yarn start --run-examples`.