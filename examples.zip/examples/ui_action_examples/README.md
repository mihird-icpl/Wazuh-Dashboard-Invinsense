## Ui actions examples

These ui actions examples shows how to:
 - Register new actions
 - Register custom triggers
 - Attach an action to a trigger

To run this example, use the command `yarn start --run-examples`.