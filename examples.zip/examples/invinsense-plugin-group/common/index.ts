export const PLUGIN_ID = 'Group Managment';
export const PLUGIN_NAME = 'Group Managment';
