Team owner: Platform

A working example of a plugin that registers and uses multiple custom routes.

Read more:

- [IRouter API Docs](../../docs/development/core/server/opensearch-dashboards-plugin-core-server.irouter.md)
- [HttpHandler (core.http.fetch) API Docs](../../docs/development/core/public/opensearch-dashboards-plugin-core-public.httphandler.md)
- [Routing Conventions](../../DEVELOPER_GUIDE.md#api-endpoints)