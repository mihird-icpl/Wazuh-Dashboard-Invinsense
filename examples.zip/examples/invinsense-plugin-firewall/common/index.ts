export const PLUGIN_ID = 'Fierwall Managment';
export const PLUGIN_NAME = 'Fierwall Managment';
