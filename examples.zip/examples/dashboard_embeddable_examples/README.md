Example of using dashboard container embeddable outside of dashboard app
