export const PLUGIN_ID = 'Configuration';
export const PLUGIN_NAME = 'Configuration';
