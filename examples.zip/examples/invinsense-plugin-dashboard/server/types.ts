// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface ConfigurationPluginSetup {}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface ConfigurationPluginStart {}
