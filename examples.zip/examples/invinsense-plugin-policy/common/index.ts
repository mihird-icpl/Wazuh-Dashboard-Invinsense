export const PLUGIN_ID = 'Policy Management';
export const PLUGIN_NAME = 'Policy Management';
