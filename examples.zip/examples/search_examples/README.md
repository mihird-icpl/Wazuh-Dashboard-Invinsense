# search_examples

> An awesome OpenSearch Dashboards plugin

---

## Development

See the [opensearchDashboards contributing guide](https://github.com/opensearch-project/OpenSearch-Dashboards/blob/main/CONTRIBUTING.md) for instructions setting up your development environment.
